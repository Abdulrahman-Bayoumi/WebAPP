# dotnetcore-webapp

Web application for demoing purposes

Project created with `dotnet new webapp`

[![Actions Status](https://github.com/rajbos/dotnetcore-webapp/workflows/.NET%20Core/badge.svg)](https://github.com/rajbos/dotnetcore-webapp/)
